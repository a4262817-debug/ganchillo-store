const products = [
  { id:1, title:"شنطة كروشية", price:95.00, img:"images/bag1.jpg" },
  { id:2, title:"محفظه كروشية", price:95.00, img:"images/hat1.jpg" },
];

const el = id => document.getElementById(id);
const productsEl = el('products');
const cartBtn = el('cart-btn');
const cartEl = el('cart');
const cartCount = el('cart-count');
const cartItemsEl = el('cart-items');
const cartTotalEl = el('cart-total');

let cart = [];

function renderProducts(){
  productsEl.innerHTML = '';
  products.forEach(p=>{
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p.img}" alt="${p.title}">
      <h3>${p.title}</h3>
      <div class="price">${p.price.toFixed(2)} ر.س</div>
      <button onclick="addToCart(${p.id})">أضف للسلة</button>
    `;
    productsEl.appendChild(card);
  });
}

function addToCart(id){
  const item = products.find(p=>p.id===id);
  const existing = cart.find(c=>c.id===id);
  if(existing){ existing.qty++; } else { cart.push({...item, qty:1}); }
  updateCartUI();
  openCart();
}

function updateCartUI(){
  cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0);
  cartItemsEl.innerHTML = '';
  cart.forEach(i=>{
    const li = document.createElement('li');
    li.innerHTML = `<span>${i.title} x${i.qty}</span><span>${(i.price * i.qty).toFixed(2)} ر.س</span>`;
    cartItemsEl.appendChild(li);
  });
  cartTotalEl.textContent = cart.reduce((s,i)=>s + i.price * i.qty, 0).toFixed(2);
}

function openCart(){ cartEl.classList.remove('hidden'); }
function closeCart(){ cartEl.classList.add('hidden'); }

function checkoutWhatsApp(){
  if(cart.length===0){ alert('السلة فارغة'); return; }
  const phone = '966504322095'; // غيريه لرقمك (بدون +) مثال للسعودية: 9665XXXXXXXX
  let text = 'طلب من متجر Ganchillo:\n';
  cart.forEach(i=>{ text += `- ${i.title} x${i.qty} = ${(i.price*i.qty).toFixed(2)} ر.س\n`; });
  text += `المجموع: ${cart.reduce((s,i)=>s+i.price*i.qty,0).toFixed(2)} ر.س\n\nالاسم:\nالعنوان:\nالهاتف:\n`;
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

function checkoutEmail(){
  if(cart.length===0){ alert('السلة فارغة'); return; }
  const to = 'aaarrr111116@icloud.com'; // غيّري للإيميل اللي تبي توصلك الطلبات
  let body = 'طلب من متجر Ganchillo:\n';
  cart.forEach(i=>{ body += `${i.title} x${i.qty} = ${(i.price*i.qty).toFixed(2)} ر.س\n`; });
  body += `المجموع: ${cart.reduce((s,i)=>s+i.price*i.qty,0).toFixed(2)} ر.س\n\nالاسم:\nالعنوان:\nالهاتف:\n`;
  window.location.href = `mailto:${to}?subject=${encodeURIComponent('طلب من متجر Ganchillo')}&body=${encodeURIComponent(body)}`;
}

cartBtn.addEventListener('click', ()=> cartEl.classList.toggle('hidden'));
el('close-cart').addEventListener('click', closeCart);
el('checkout-watsapp').addEventListener('click', checkoutWhatsApp);
el('checkout-email').addEventListener('click', checkoutEmail);

renderProducts();
updateCartUI();
window.addToCart = addToCart;